Peasone v1.0; 050221

This font is part of FanProject, stay tune for more info...

Peasone is free for personal, educational, non-profit, or charitable use. 
For commercial use, please consider donating to help me create a fully functional font.
Every donation is greatly appreciated.

Donation:
https://www.paypal.com/paypalme/moonotonous

If you require any further information, feel free to contact me on Discord at Froastroast#1515



Thanks for being supportive,
Moonotonous